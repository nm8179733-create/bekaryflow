
import { AppState, DailySale, SupplierPayment, FixedExpense } from '../types';

const STORAGE_KEY = 'bakeryflow_v1_data';

const DEFAULT_STATE: AppState = {
  sales: [],
  payments: [],
  fixedExpenses: [
    { id: '1', type: 'Rent' as any, amount: 25000, isRecurring: true, name: 'Shop Rent' },
    { id: '2', type: 'Staff Salary' as any, amount: 45000, isRecurring: true, name: 'Staff Salaries' }
  ],
  suppliers: []
};

export const loadData = (): AppState => {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse saved data', e);
    }
  }
  return DEFAULT_STATE;
};

export const saveData = (state: AppState) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
};

export const getMonthYear = (dateStr: string) => {
  const d = new Date(dateStr);
  return `${d.getMonth() + 1}-${d.getFullYear()}`;
};

export const getTodayStr = () => new Date().toISOString().split('T')[0];

export const calculatePL = (state: AppState, month?: number, year?: number) => {
  const now = new Date();
  const targetMonth = month !== undefined ? month : now.getMonth();
  const targetYear = year !== undefined ? year : now.getFullYear();

  const filteredSales = state.sales.filter(s => {
    const d = new Date(s.date);
    return d.getMonth() === targetMonth && d.getFullYear() === targetYear;
  });

  const filteredPayments = state.payments.filter(p => {
    const d = new Date(p.date);
    return d.getMonth() === targetMonth && d.getFullYear() === targetYear;
  });

  const totalSales = filteredSales.reduce((acc, curr) => acc + curr.totalAmount, 0);
  const totalCashSales = filteredSales.reduce((acc, curr) => acc + curr.cashAmount, 0);
  const totalUpiSales = filteredSales.reduce((acc, curr) => acc + curr.upiAmount, 0);
  
  const supplierExpenses = filteredPayments.reduce((acc, curr) => acc + curr.amount, 0);
  const fixedExpenses = state.fixedExpenses.reduce((acc, curr) => acc + curr.amount, 0);
  
  const totalExpenses = supplierExpenses + fixedExpenses;
  const netProfit = totalSales - totalExpenses;
  const profitMargin = totalSales > 0 ? (netProfit / totalSales) * 100 : 0;

  return {
    totalSales,
    totalCashSales,
    totalUpiSales,
    supplierExpenses,
    fixedExpenses,
    totalExpenses,
    netProfit,
    profitMargin
  };
};
