
import React from 'react';
import { AppState } from '../types';
import { calculatePL } from '../services/dataService';
import { formatCurrency } from '../constants';

interface ReportsProps {
  state: AppState;
}

const Reports: React.FC<ReportsProps> = ({ state }) => {
  const pl = calculatePL(state);
  
  const handleExport = () => {
    const csvRows = [
      ['Date', 'Cash Sales', 'UPI Sales', 'Total Sales'],
      ...state.sales.map(s => [s.date, s.cashAmount, s.upiAmount, s.totalAmount])
    ];
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + csvRows.map(e => e.join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `BakeryFlow_Report_${new Date().toLocaleDateString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="pb-24 pt-6 px-4 space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Reports</h1>
          <p className="text-slate-500 text-sm">Performance analysis</p>
        </div>
        <button 
          onClick={handleExport}
          className="bg-emerald-600 text-white px-4 py-2 rounded-xl flex items-center space-x-2 text-sm font-bold shadow-lg"
        >
          <i className="fas fa-file-csv"></i>
          <span>EXPORT</span>
        </button>
      </header>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm text-center">
          <p className="text-[10px] font-bold text-slate-400 uppercase mb-2">Cash Flow</p>
          <div className="flex justify-center space-x-1 items-end h-16 mb-2">
            <div className="w-6 bg-emerald-500 rounded-t-lg" style={{ height: `${(pl.totalCashSales/pl.totalSales)*100}%` }}></div>
            <div className="w-6 bg-blue-500 rounded-t-lg" style={{ height: `${(pl.totalUpiSales/pl.totalSales)*100}%` }}></div>
          </div>
          <p className="text-xs font-bold text-slate-800">
            {Math.round((pl.totalCashSales/pl.totalSales)*100 || 0)}% Cash
          </p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm text-center">
          <p className="text-[10px] font-bold text-slate-400 uppercase mb-2">Efficiency</p>
          <div className="relative w-16 h-16 mx-auto mb-2 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-slate-100" />
              <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="8" fill="transparent" strokeDasharray={175.9} strokeDashoffset={175.9 - (175.9 * pl.profitMargin / 100)} className="text-blue-500" strokeLinecap="round" />
            </svg>
            <span className="absolute text-[10px] font-black">{Math.round(pl.profitMargin)}%</span>
          </div>
          <p className="text-xs font-bold text-slate-800">Profit Margin</p>
        </div>
      </div>

      <section className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <h3 className="p-4 font-bold text-slate-800 border-b border-slate-50 uppercase text-xs tracking-wider">Recent Daily Log</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[9px] font-black">
              <tr>
                <th className="p-4">Date</th>
                <th className="p-4 text-right">Sales</th>
                <th className="p-4 text-right">Profit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {state.sales.length > 0 ? state.sales.slice(-7).reverse().map(sale => (
                <tr key={sale.id}>
                  <td className="p-4 font-medium text-slate-600">{new Date(sale.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</td>
                  <td className="p-4 text-right font-bold text-slate-900">{formatCurrency(sale.totalAmount)}</td>
                  <td className="p-4 text-right text-emerald-600 font-bold">
                    {formatCurrency(sale.totalAmount * (pl.profitMargin / 100))}
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={3} className="p-10 text-center text-slate-400 italic">No sales data recorded yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default Reports;
