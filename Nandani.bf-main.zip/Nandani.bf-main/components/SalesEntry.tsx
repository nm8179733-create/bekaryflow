
import React, { useState } from 'react';
import { DailySale } from '../types';
import { formatCurrency } from '../constants';
import { getTodayStr } from '../services/dataService';

interface SalesEntryProps {
  sales: DailySale[];
  onAddSale: (sale: DailySale) => void;
}

const SalesEntry: React.FC<SalesEntryProps> = ({ sales, onAddSale }) => {
  const [date, setDate] = useState(getTodayStr());
  const [cash, setCash] = useState('');
  const [upi, setUpi] = useState('');

  const total = (parseFloat(cash) || 0) + (parseFloat(upi) || 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (total <= 0) return;

    const newSale: DailySale = {
      id: Math.random().toString(36).substr(2, 9),
      date,
      cashAmount: parseFloat(cash) || 0,
      upiAmount: parseFloat(upi) || 0,
      totalAmount: total,
    };
    onAddSale(newSale);
    setCash('');
    setUpi('');
    alert('Sale saved successfully!');
  };

  const currentSale = sales.find(s => s.date === date);

  return (
    <div className="pb-24 pt-6 px-4 space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Record Sales</h1>
        <p className="text-slate-500 text-sm">Quick entry for daily collection</p>
      </header>

      {currentSale && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center space-x-3 text-amber-800">
          <i className="fas fa-info-circle text-amber-500"></i>
          <p className="text-sm font-medium">Sales for this date are already recorded: <span className="font-bold">{formatCurrency(currentSale.totalAmount)}</span></p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Select Date</label>
          <input 
            type="date" 
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full bg-slate-50 border-none rounded-xl p-4 text-lg font-semibold focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Cash Amount</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">₹</span>
              <input 
                type="number" 
                inputMode="numeric"
                placeholder="0"
                value={cash}
                onChange={(e) => setCash(e.target.value)}
                className="w-full bg-slate-50 border-none rounded-xl p-4 pl-9 text-lg font-bold focus:ring-2 focus:ring-green-500 outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">UPI / Card</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">₹</span>
              <input 
                type="number" 
                inputMode="numeric"
                placeholder="0"
                value={upi}
                onChange={(e) => setUpi(e.target.value)}
                className="w-full bg-slate-50 border-none rounded-xl p-4 pl-9 text-lg font-bold focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-2xl flex justify-between items-center text-white">
          <span className="font-medium opacity-80 uppercase text-xs tracking-widest">Calculated Total</span>
          <span className="text-2xl font-black">{formatCurrency(total)}</span>
        </div>

        <button 
          type="submit"
          className="w-full bg-blue-600 active:bg-blue-700 text-white font-bold py-5 rounded-2xl shadow-lg shadow-blue-200 transition-all flex items-center justify-center space-x-2"
        >
          <i className="fas fa-check-circle"></i>
          <span>SAVE DAILY SALES</span>
        </button>
      </form>
    </div>
  );
};

export default SalesEntry;
