
import React from 'react';
import { FixedExpense, FixedExpenseType } from '../types';
import { formatCurrency, EXPENSE_ICONS } from '../constants';

interface FixedExpensesProps {
  expenses: FixedExpense[];
  onUpdateExpense: (id: string, amount: number) => void;
}

const FixedExpenses: React.FC<FixedExpensesProps> = ({ expenses, onUpdateExpense }) => {
  const totalFixed = expenses.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="pb-24 pt-6 px-4 space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Fixed Expenses</h1>
        <p className="text-slate-500 text-sm">Monthly recurring operating costs</p>
      </header>

      <div className="bg-slate-900 p-6 rounded-3xl text-white shadow-xl">
        <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Total Monthly Burn</p>
        <h2 className="text-3xl font-black">{formatCurrency(totalFixed)}</h2>
        <div className="mt-4 flex items-center text-xs text-blue-400 bg-blue-900/30 p-2 rounded-lg inline-flex">
          <i className="fas fa-info-circle mr-2"></i>
          These are deducted automatically from your P&L
        </div>
      </div>

      <div className="space-y-4">
        {expenses.map((expense) => (
          <div key={expense.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-xl">
                {EXPENSE_ICONS[expense.type]}
              </div>
              <div>
                <h4 className="font-bold text-slate-800">{expense.name}</h4>
                <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">{expense.type}</p>
              </div>
            </div>
            <div className="relative max-w-[120px]">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">₹</span>
              <input 
                type="number"
                value={expense.amount}
                onChange={(e) => onUpdateExpense(expense.id, parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-50 pl-7 p-3 rounded-lg text-right font-bold text-slate-800 border-none outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border-2 border-dashed border-slate-200 p-8 rounded-2xl flex flex-col items-center justify-center text-slate-400">
        <i className="fas fa-plus-circle text-2xl mb-2"></i>
        <p className="text-xs font-bold uppercase">Add New Recurring Cost</p>
        <p className="text-[10px] mt-1">(Future release feature)</p>
      </div>
    </div>
  );
};

export default FixedExpenses;
