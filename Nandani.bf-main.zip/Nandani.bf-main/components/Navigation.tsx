
import React from 'react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'dashboard', label: 'Home', icon: 'fa-home' },
    { id: 'sales', label: 'Sales', icon: 'fa-indian-rupee-sign' },
    { id: 'payments', label: 'Suppliers', icon: 'fa-truck' },
    { id: 'expenses', label: 'Fixed', icon: 'fa-receipt' },
    { id: 'reports', label: 'Reports', icon: 'fa-chart-pie' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-2 py-1 flex justify-around items-center z-50">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id)}
          className={`flex flex-col items-center py-2 px-3 rounded-xl transition-colors ${
            activeTab === tab.id ? 'text-blue-600 font-semibold' : 'text-slate-500'
          }`}
        >
          <i className={`fas ${tab.icon} text-xl mb-1`}></i>
          <span className="text-[10px] uppercase tracking-wider">{tab.label}</span>
          {activeTab === tab.id && <div className="h-1 w-4 bg-blue-600 rounded-full mt-1"></div>}
        </button>
      ))}
    </nav>
  );
};

export default Navigation;
