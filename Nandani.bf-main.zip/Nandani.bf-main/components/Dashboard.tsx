
import React from 'react';
import { AppState } from '../types';
import { calculatePL, getTodayStr } from '../services/dataService';
import { formatCurrency } from '../constants';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

interface DashboardProps {
  state: AppState;
}

const Dashboard: React.FC<DashboardProps> = ({ state }) => {
  const pl = calculatePL(state);
  const todayStr = getTodayStr();
  const todaySale = state.sales.find(s => s.date === todayStr);
  const todayPayments = state.payments.filter(p => p.date === todayStr);
  const todayExpense = todayPayments.reduce((acc, curr) => acc + curr.amount, 0);
  const todayProfit = (todaySale?.totalAmount || 0) - todayExpense;

  const cashData = [
    { name: 'Cash', value: pl.totalCashSales, color: '#10B981' },
    { name: 'UPI', value: pl.totalUpiSales, color: '#3B82F6' },
  ];

  const topSuppliers = React.useMemo(() => {
    const map: Record<string, number> = {};
    state.payments.forEach(p => {
      map[p.supplierName] = (map[p.supplierName] || 0) + p.amount;
    });
    return Object.entries(map)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [state.payments]);

  return (
    <div className="pb-24 pt-4 px-4 space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">BakeryFlow</h1>
          <p className="text-slate-500 text-sm">{new Date().toLocaleDateString('en-IN', { dateStyle: 'full' })}</p>
        </div>
        <div className="bg-blue-100 p-3 rounded-full">
          <i className="fas fa-store text-blue-600 text-xl"></i>
        </div>
      </header>

      {/* Today's Stats Row */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-slate-500 text-xs font-medium uppercase mb-1">Today Sales</p>
          <p className="text-xl font-bold text-slate-900">{formatCurrency(todaySale?.totalAmount || 0)}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-slate-500 text-xs font-medium uppercase mb-1">Today Profit</p>
          <p className={`text-xl font-bold ${todayProfit >= 0 ? 'text-green-600' : 'text-red-500'}`}>
            {formatCurrency(todayProfit)}
          </p>
        </div>
      </div>

      {/* Monthly Progress Card */}
      <section className="bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-3xl text-white shadow-lg shadow-blue-200">
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-blue-100 text-sm opacity-80 uppercase font-semibold">Monthly Net Profit</p>
            <h2 className="text-3xl font-bold mt-1">{formatCurrency(pl.netProfit)}</h2>
          </div>
          <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
            <span className="text-xs font-bold">{pl.profitMargin.toFixed(1)}% Margin</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/20">
          <div>
            <p className="text-blue-100 text-[10px] uppercase opacity-70">Total Sales</p>
            <p className="text-lg font-semibold">{formatCurrency(pl.totalSales)}</p>
          </div>
          <div>
            <p className="text-blue-100 text-[10px] uppercase opacity-70">Total Expenses</p>
            <p className="text-lg font-semibold">{formatCurrency(pl.totalExpenses)}</p>
          </div>
        </div>
      </section>

      {/* Cash Flow Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <h3 className="text-sm font-bold text-slate-700 mb-4 uppercase flex items-center">
            <i className="fas fa-wallet mr-2 text-blue-500"></i> Cash vs UPI
          </h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={cashData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {cashData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-around mt-2">
            {cashData.map(item => (
              <div key={item.name} className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                <span className="text-xs text-slate-600">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Suppliers List */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <h3 className="text-sm font-bold text-slate-700 mb-4 uppercase flex items-center">
            <i className="fas fa-truck-loading mr-2 text-amber-500"></i> Top Suppliers
          </h3>
          <div className="space-y-4">
            {topSuppliers.length > 0 ? topSuppliers.map(([name, amount], i) => (
              <div key={name} className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="w-6 h-6 rounded bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-500 mr-3">{i+1}</span>
                  <span className="text-sm font-medium text-slate-800">{name}</span>
                </div>
                <span className="text-sm font-semibold text-slate-900">{formatCurrency(amount)}</span>
              </div>
            )) : (
              <p className="text-slate-400 text-xs italic">No supplier payments yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
