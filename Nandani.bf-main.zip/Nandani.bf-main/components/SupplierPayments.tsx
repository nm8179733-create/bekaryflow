
import React, { useState, useEffect } from 'react';
import { SupplierPayment, PaymentMode } from '../types';
import { formatCurrency, CATEGORY_ICONS } from '../constants';
import { getTodayStr } from '../services/dataService';

interface SupplierPaymentsProps {
  payments: SupplierPayment[];
  suppliers: string[];
  onAddPayment: (payment: SupplierPayment) => void;
}

const SupplierPayments: React.FC<SupplierPaymentsProps> = ({ payments, suppliers, onAddPayment }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [isCustomSupplier, setIsCustomSupplier] = useState(suppliers.length === 0);
  const [isCustomCategory, setIsCustomCategory] = useState(true);
  const [formData, setFormData] = useState<{
    supplierName: string;
    amount: string;
    mode: PaymentMode;
    category: string;
    notes: string;
  }>({
    supplierName: suppliers[0] || '',
    amount: '',
    mode: PaymentMode.CASH,
    category: '',
    notes: ''
  });

  // Reset custom states when opening modal
  useEffect(() => {
    if (isAdding) {
      setIsCustomSupplier(suppliers.length === 0);
      setIsCustomCategory(true);
      setFormData(prev => ({
        ...prev,
        supplierName: suppliers[0] || '',
        category: ''
      }));
    }
  }, [isAdding, suppliers]);

  const sortedPayments = [...payments].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amount || parseFloat(formData.amount) <= 0) return;

    const newPayment: SupplierPayment = {
      id: Math.random().toString(36).substr(2, 9),
      date: getTodayStr(),
      ...formData,
      amount: parseFloat(formData.amount)
    };
    onAddPayment(newPayment);
    setIsAdding(false);
    setIsCustomSupplier(false);
    setIsCustomCategory(false);
    setFormData({ ...formData, amount: '', notes: '' });
  };

  return (
    <div className="pb-24 pt-6 px-4 space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Supplier Payments</h1>
          <p className="text-slate-500 text-sm">Manage vendor expenses</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-blue-600 text-white w-12 h-12 rounded-2xl shadow-lg flex items-center justify-center"
        >
          <i className="fas fa-plus"></i>
        </button>
      </header>

      {isAdding && (
        <div className="fixed inset-0 z-[60] bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-bold text-lg">New Payment</h3>
              <button onClick={() => setIsAdding(false)} className="text-slate-400">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Supplier</label>
                <div className="space-y-2">
                  <select 
                    className="w-full bg-slate-50 p-4 rounded-xl font-semibold border-none outline-none focus:ring-2 focus:ring-blue-500"
                    value={isCustomSupplier ? 'CUSTOM' : formData.supplierName}
                    onChange={(e) => {
                      if (e.target.value === 'CUSTOM') {
                        setIsCustomSupplier(true);
                        setFormData({...formData, supplierName: ''});
                      } else {
                        setIsCustomSupplier(false);
                        setFormData({...formData, supplierName: e.target.value});
                      }
                    }}
                  >
                    {suppliers.map(s => <option key={s} value={s}>{s}</option>)}
                    <option value="CUSTOM">+ Add New Supplier</option>
                  </select>
                  {isCustomSupplier && (
                    <input 
                      type="text"
                      placeholder="Enter supplier name"
                      className="w-full bg-slate-50 p-4 rounded-xl font-semibold border-none outline-none focus:ring-2 focus:ring-blue-500 animate-in slide-in-from-top-2"
                      value={formData.supplierName}
                      onChange={(e) => setFormData({...formData, supplierName: e.target.value})}
                      autoFocus
                    />
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Amount</label>
                  <input 
                    type="number" 
                    placeholder="₹ 0.00"
                    className="w-full bg-slate-50 p-4 rounded-xl font-bold border-none outline-none focus:ring-2 focus:ring-blue-500"
                    value={formData.amount}
                    onChange={(e) => setFormData({...formData, amount: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Mode</label>
                  <select 
                    className="w-full bg-slate-50 p-4 rounded-xl font-semibold border-none outline-none focus:ring-2 focus:ring-blue-500"
                    value={formData.mode}
                    onChange={(e) => setFormData({...formData, mode: e.target.value as PaymentMode})}
                  >
                    {Object.values(PaymentMode).map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Category</label>
                <div className="space-y-2">
                  <select 
                    className="w-full bg-slate-50 p-4 rounded-xl font-semibold border-none outline-none focus:ring-2 focus:ring-blue-500"
                    value={isCustomCategory ? 'CUSTOM' : formData.category}
                    onChange={(e) => {
                      if (e.target.value === 'CUSTOM') {
                        setIsCustomCategory(true);
                        setFormData({...formData, category: ''});
                      } else {
                        setIsCustomCategory(false);
                        setFormData({...formData, category: e.target.value});
                      }
                    }}
                  >
                    <option value="CUSTOM">+ Add New Category</option>
                  </select>
                  {isCustomCategory && (
                    <input 
                      type="text"
                      placeholder="Enter category name"
                      className="w-full bg-slate-50 p-4 rounded-xl font-semibold border-none outline-none focus:ring-2 focus:ring-blue-500 animate-in slide-in-from-top-2"
                      value={formData.category}
                      onChange={(e) => setFormData({...formData, category: e.target.value})}
                      autoFocus
                    />
                  )}
                </div>
              </div>
              <button className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg mt-2">
                SUBMIT PAYMENT
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {sortedPayments.length > 0 ? sortedPayments.map(p => (
          <div key={p.id} className="bg-white p-4 rounded-2xl border border-slate-100 flex items-center space-x-4">
            <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-xl">
              {CATEGORY_ICONS[p.category] || <i className="fas fa-tag text-slate-400"></i>}
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-slate-800">{p.supplierName}</h4>
              <p className="text-[10px] text-slate-400 uppercase tracking-wide">
                {new Date(p.date).toLocaleDateString('en-IN')} • {p.mode}
              </p>
            </div>
            <div className="text-right">
              <p className="font-bold text-slate-900">{formatCurrency(p.amount)}</p>
              <p className="text-[10px] text-slate-400 uppercase tracking-wide">{p.category}</p>
            </div>
          </div>
        )) : (
          <div className="py-20 text-center space-y-4">
            <div className="bg-slate-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto text-slate-300 text-3xl">
              <i className="fas fa-truck"></i>
            </div>
            <p className="text-slate-400 font-medium">No payments recorded yet</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SupplierPayments;
